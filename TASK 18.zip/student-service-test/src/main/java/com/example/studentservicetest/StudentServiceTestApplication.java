package com.example.studentservicetest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentServiceTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentServiceTestApplication.class, args);
    }
}