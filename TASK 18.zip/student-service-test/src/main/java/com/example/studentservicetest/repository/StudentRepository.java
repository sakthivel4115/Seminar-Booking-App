package com.example.studentservicetest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.studentservicetest.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
}