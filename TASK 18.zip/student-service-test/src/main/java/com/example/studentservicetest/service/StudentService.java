package com.example.studentservicetest.service;

import org.springframework.stereotype.Service;

@Service
public class StudentService {

    public String getStudent() {
        return "Student Data";
    }
}