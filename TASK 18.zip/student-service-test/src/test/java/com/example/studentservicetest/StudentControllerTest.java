package com.example.studentservicetest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.studentservicetest.controller.StudentController;
import com.example.studentservicetest.service.StudentService;

@WebMvcTest(StudentController.class)
class StudentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StudentService service;

    @Test
    void testController() throws Exception {

        Mockito.when(service.getStudent())
               .thenReturn("Student Data");

        mockMvc.perform(get("/students"))
               .andExpect(status().isOk())
               .andExpect(content().string("Student Data"));
    }
}