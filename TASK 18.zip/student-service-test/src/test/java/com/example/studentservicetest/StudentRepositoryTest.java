package com.example.studentservicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.studentservicetest.entity.Student;
import com.example.studentservicetest.repository.StudentRepository;

@DataJpaTest
class StudentRepositoryTest {

    @Autowired
    private StudentRepository repo;

    @Test
    void testRepo() {
        Student s = new Student(1, "John");
        Student saved = repo.save(s);

        assertEquals("John", saved.getName());
    }
}